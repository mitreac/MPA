## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(MPA)
file_name <- "test_expr_file.txt"
df = data.frame(cond = c(10,12), ctrl = c(11,20), row.names = c("m1","m2"))
write.table(df, file_name, sep = "\t")

df1 <- read_expression_data(file_name)
df1

## -----------------------------------------------------------------------------
?read_expression_data

